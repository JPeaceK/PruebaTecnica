import unittest
import increasingFunction


y = increasingFunction.f(123456789) # value in the range

z = y + 1e-8 # value not in the range


class TestFind(unittest.TestCase):
    def test_y(self):
        self.assertEqual(increasingFunction.find(y, 0, 10000000000), 123456789, "Should be 123456789")
    def test_z(self):
        self.assertEqual(increasingFunction.find(z, 0, 10000000000), -1, "Should be -1")
    def test_zero(self):
        self.assertEqual(increasingFunction.find(0.0, 0, 10000), 0, "Should be 0")
    def test_negative(self):
        self.assertEqual(increasingFunction.find(0.0, -10, -10), -10, "Should be -10")
        
if __name__ == '__main__':
    unittest.main()
