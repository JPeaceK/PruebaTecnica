from mpmath import zetazero # need mpmath installed

def f(n):
    return 0. if n <= 0 else float(zetazero(n).imag)

def find(y, a, b):
    """
    This function searches for an integer 'n' in the range [a, b] such that f(n) = y.\n
    If such a number 'n' exists, the function returns 'n'. \n
    If it does not exist, the function returns -1.

    Args:
        y (float): an arbitrary floating point number
        a (int): start of range [a,b]
        b (int): end of range [a,b]

    Returns:
        n (int):    if for any integer n with a ≤ n ≤ b we have that f(n) = y
        -1:         if there is no such n with a ≤ n ≤ b and f(n) = y
    """
    while(a<=b):
        # Calculate the middle point of the current range for binary search
        aux = a + (b - a) // 2
        if f(aux) == y:
            return aux
        # As f(n) is an increasing function, we will narrow down the range in the following way
        elif f(aux) > y:
            b = aux-1
        else:
            a = aux+1
    return -1
