#include <iostream>
#include "shapes.h"

using namespace std;
const float PI = 3.14159;

Triangle::Triangle(float base, float heigth, float sideA, float sideB) : base(base), height(height) , sideA(sideA), sideB(sideB) {}

float Triangle::calculateArea() {
    return (base * height) / 2;
}

float Triangle::calculatePerimeter() {
    return base + sideA + sideB;
}

Square::Square(float side) : side(side) {}

float Square::calculateArea() {
    return side * side;
}

float Square::calculatePerimeter() {
    return side*4;
}

Circle::Circle(float radius) : radius(radius) {}

float Circle::calculateArea() {
    return PI * radius * radius;
}

float Circle::calculatePerimeter() {
    return PI * 2 * radius;
}