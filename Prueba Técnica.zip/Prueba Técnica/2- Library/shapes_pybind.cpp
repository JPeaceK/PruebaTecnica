#include <pybind11/pybind11.h>
#include "shapes.h"

namespace py = pybind11;

PYBIND11_MODULE(shape_library, m) {
    py::class_<Shape>(m, "Shape")
        .def("calculateArea", &Shape::calculateArea)
        .def("calculatePerimeter", &Shape::calculatePerimeter);

    py::class_<Triangle, Shape>(m, "Triangle")
        .def(py::init<float, float, float, float>())
        .def("calculateArea", &Triangle::calculateArea)
        .def("calculatePerimeter", &Triangle::calculatePerimeter);

    py::class_<Square, Shape>(m, "Square")
        .def(py::init<float>())
        .def("calculateArea", &Square::calculateArea)
        .def("calculatePerimeter", &Square::calculatePerimeter);

    py::class_<Circle, Shape>(m, "Circle")
        .def(py::init<float>())
        .def("calculateArea", &Circle::calculateArea)
        .def("calculatePerimeter", &Circle::calculatePerimeter);
}
