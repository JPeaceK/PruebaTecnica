class Shape {
public:
    virtual float calculateArea() = 0;
    virtual float calculatePerimeter() = 0;
};

class Triangle : public Shape {
    public:
        Triangle(float base, float height, float sideA, float sideB);
        float calculateArea();
        float calculatePerimeter();
    private:
        float base;
        float height;
        float sideA;
        float sideB;
};

class Square : public Shape {
    public:
        Square(float side);
        float calculateArea();
        float calculatePerimeter();
    private:
        float side;
};

class Circle : public Shape {
    public:
        Circle(float radius);
        float calculateArea();
        float calculatePerimeter();
    private:
    float radius;
};