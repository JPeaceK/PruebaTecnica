from shape_library import Triangle, Square, Circle

my_triangle = Triangle(3.0, 4.0, 5.0, 6.0)
print(f"Triangle area is {my_triangle.calculateArea()}")
print(f"Triangle perimeter is {my_triangle.calculatePerimeter()}")

my_square = Square(5.0)
print(f"Square area is {my_square.calculateArea()}")
print(f"Square perimeter is {my_square.calculatePerimeter()}")

my_circle = Circle(2.0)
print(f"Circle area is {my_circle.calculateArea()}")
print(f"Circle perimeter is {my_circle.calculatePerimeter()}")
